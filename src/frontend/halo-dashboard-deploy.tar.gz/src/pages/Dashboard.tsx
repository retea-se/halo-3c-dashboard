/**
 * Dashboard Page - Huvudsida med sensor cards och beacon list
 */
import React, { useEffect, useState } from 'react';
import { apiService } from '../services/api';
import { SensorCard } from '../components/sensors/SensorCard';
import { BeaconList } from '../components/beacons/BeaconList';
import { useWebSocket } from '../hooks/useWebSocket';
import { useToast } from '../hooks/useToast';
import { ToastContainer } from '../components/ui/Toast';

interface SensorData {
  sensor_id: string;
  timestamp: string;
  values: Record<string, number>;
}

interface LatestSensorsResponse {
  device_id: string;
  timestamp: string;
  sensors: SensorData[];
}

export const Dashboard: React.FC = () => {
  const [sensors, setSensors] = useState<SensorData[]>([]);
  const [sensorMetadata, setSensorMetadata] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { toasts, showToast, removeToast } = useToast();

  // WebSocket connection för real-time events
  const { lastMessage } = useWebSocket('ws://localhost:8000/api/events/stream');

  // Ladda sensor metadata
  useEffect(() => {
    const loadMetadata = async () => {
      try {
        const metadata = await apiService.getSensorMetadata();
        setSensorMetadata(metadata);
      } catch (error) {
        console.error('Failed to load sensor metadata:', error);
      }
    };
    loadMetadata();
  }, []);

  // Ladda senaste sensorvärden
  useEffect(() => {
    const loadSensors = async () => {
      try {
        setLoading(true);
        const response: LatestSensorsResponse = await apiService.getLatestSensors();
        setSensors(response.sensors || []);
      } catch (error) {
        console.error('Failed to load sensors:', error);
        showToast('Kunde inte ladda sensorvärden', 'error');
      } finally {
        setLoading(false);
      }
    };

    loadSensors();
    // Uppdatera varje 10 sekunder
    const interval = setInterval(loadSensors, 10000);
    return () => clearInterval(interval);
  }, [showToast]);

  // Hantera WebSocket events
  useEffect(() => {
    if (lastMessage) {
      try {
        const data = JSON.parse(lastMessage.data);
        if (data.type === 'new_event') {
          const event = data.event;
          // Visa toast för kritiska events
          if (event.severity === 'CRITICAL' || event.severity === 'WARNING') {
            const severity: 'error' | 'warning' = event.severity === 'CRITICAL' ? 'error' : 'warning';
            showToast(event.summary, severity, 8000);
          }
          // Speciell hantering för panikknapp-events
          if (event.type === 'BEACON_PANIC_BUTTON') {
            showToast(`PANIKKNAPP: ${event.summary}`, 'error', 15000);
          }
        }
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    }
  }, [lastMessage, showToast]);

  // Kombinera sensor data med metadata
  const sensorsWithMetadata = sensors.map((sensor) => {
    const metadata = sensorMetadata.find((m) => {
      // Matcha sensor_id med metadata id
      const sensorKey = sensor.sensor_id.split('/')[0];
      return m.id.includes(sensorKey) || m.technical_name.includes(sensorKey);
    });
    return {
      ...sensor,
      metadata,
    };
  });

  // Gruppera sensorer per kategori
  const sensorsByCategory = sensorsWithMetadata.reduce((acc, sensor) => {
    const category = sensor.metadata?.category || 'Övrigt';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(sensor);
    return acc;
  }, {} as Record<string, typeof sensorsWithMetadata>);

  return (
    <div style={{ padding: 'var(--spacing-lg)', maxWidth: '1400px', margin: '0 auto' }}>
      <ToastContainer toasts={toasts} onClose={removeToast} />
      <h1 style={{ marginBottom: 'var(--spacing-xl)' }}>Dashboard</h1>

      {loading && sensors.length === 0 ? (
        <div>Laddar sensorvärden...</div>
      ) : (
        <>
          {/* Sensor Cards grupperade per kategori */}
          {Object.entries(sensorsByCategory).map(([category, categorySensors]) => (
            <div key={category} style={{ marginBottom: 'var(--spacing-xl)' }}>
              <h2
                style={{
                  fontSize: 'var(--font-size-lg)',
                  fontWeight: 600,
                  marginBottom: 'var(--spacing-md)',
                  color: 'var(--color-text-secondary)',
                }}
              >
                {category}
              </h2>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
                  gap: 'var(--spacing-md)',
                }}
              >
                {categorySensors.map((sensor) => (
                  <SensorCard
                    key={sensor.sensor_id}
                    sensorData={sensor}
                    metadata={sensor.metadata}
                  />
                ))}
              </div>
            </div>
          ))}

          {/* Beacon List */}
          <div style={{ marginTop: 'var(--spacing-xl)' }}>
            <h2
              style={{
                fontSize: 'var(--font-size-lg)',
                fontWeight: 600,
                marginBottom: 'var(--spacing-md)',
                color: 'var(--color-text-secondary)',
              }}
            >
              BLE Beacons
            </h2>
            <BeaconList />
          </div>
        </>
      )}
    </div>
  );
};

