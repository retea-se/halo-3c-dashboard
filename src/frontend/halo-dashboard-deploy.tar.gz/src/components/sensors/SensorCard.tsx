/**
 * SensorCard - Visar enskild sensor med värde, metadata och tooltip/popover
 */
import React, { useState } from 'react';
import { Card } from '../ui/Card';
import { Icon } from '../ui/Icon';
import { SensorInfoPopover } from './SensorInfoPopover';
import { useTheme } from '../../theme/ThemeProvider';

interface SensorCardProps {
  sensorData: {
    sensor_id: string;
    timestamp: string;
    values: Record<string, number>;
    metadata?: any;
  };
  metadata?: any;
}

export const SensorCard: React.FC<SensorCardProps> = ({ sensorData, metadata }) => {
  const { colors } = useTheme();
  const [showPopover, setShowPopover] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);

  // Hämta första värdet (för nu, kan utökas)
  const firstValue = Object.values(sensorData.values)[0];
  const value = firstValue !== undefined ? firstValue : null;

  const sensorMeta = metadata || sensorData.metadata;
  const displayName = sensorMeta?.display_name || sensorData.sensor_id;
  const unit = sensorMeta?.unit || '';
  const shortDescription = sensorMeta?.short_description || '';
  const normalRange = sensorMeta?.normal_range;

  // Bestäm status baserat på normal range
  let statusColor = colors.text.secondary;
  if (normalRange && value !== null) {
    if (value >= normalRange.min && value <= normalRange.max) {
      statusColor = colors.success;
    } else if (normalRange.min && value < normalRange.min) {
      statusColor = colors.warning;
    } else if (normalRange.max && value > normalRange.max) {
      statusColor = colors.error;
    }
  }

  return (
    <Card padding="md" style={{ position: 'relative' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div style={{ flex: 1 }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 'var(--spacing-xs)',
              marginBottom: 'var(--spacing-xs)',
            }}
          >
            <h3
              style={{
                fontSize: 'var(--font-size-md)',
                fontWeight: 600,
                margin: 0,
                color: 'var(--color-text-primary)',
              }}
            >
              {displayName}
            </h3>
            {/* Info icon för popover */}
            <div
              style={{ position: 'relative', cursor: 'pointer' }}
              onMouseEnter={() => setShowTooltip(true)}
              onMouseLeave={() => setShowTooltip(false)}
              onClick={() => setShowPopover(!showPopover)}
            >
              <Icon
                name="info-icon"
                size={16}
                color={colors.text.secondary}
                style={{ opacity: 0.6 }}
              />
              {showTooltip && (
                <div
                  style={{
                    position: 'absolute',
                    bottom: '100%',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    marginBottom: 'var(--spacing-xs)',
                    padding: 'var(--spacing-xs) var(--spacing-sm)',
                    backgroundColor: 'var(--color-surface-elevated)',
                    color: 'var(--color-text-primary)',
                    fontSize: 'var(--font-size-sm)',
                    borderRadius: 'var(--radius-sm)',
                    whiteSpace: 'nowrap',
                    boxShadow: 'var(--shadow-md)',
                    zIndex: 100,
                  }}
                >
                  {shortDescription || 'Klicka för mer information'}
                </div>
              )}
            </div>
          </div>
          {value !== null ? (
            <div
              style={{
                fontSize: 'var(--font-size-2xl)',
                fontWeight: 700,
                color: statusColor,
                marginBottom: 'var(--spacing-xs)',
              }}
            >
              {value.toFixed(1)} {unit}
            </div>
          ) : (
            <div style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)' }}>
              Inga data
            </div>
          )}
          {normalRange && (
            <div
              style={{
                fontSize: 'var(--font-size-xs)',
                color: 'var(--color-text-secondary)',
                marginTop: 'var(--spacing-xs)',
              }}
            >
              Normal: {normalRange.min}–{normalRange.max} {unit}
            </div>
          )}
        </div>
      </div>

      {/* Popover för detaljerad information */}
      {showPopover && sensorMeta && (
        <SensorInfoPopover
          metadata={sensorMeta}
          onClose={() => setShowPopover(false)}
        />
      )}
    </Card>
  );
};

